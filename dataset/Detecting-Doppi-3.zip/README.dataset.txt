# Detecting Doppi > 2024-01-25 7:32pm
https://universe.roboflow.com/labelingdoppi/detecting-doppi

Provided by a Roboflow user
License: CC BY 4.0

